This is a plugin to facilitate GeoIP lookups using MaxMind's GeoIPCity database and Java APIs.

TODOs:
I18n strings
Add Support for Region Database
Add Support for Metro Database
Add Support for Netspeed Database - Hack Should Work
Add Support for DomainName Database - Hack works
Add Support for Accuracy Radius DB
Add support for IPv6 - now available in GeoIP v1.2.4

Make the file location work as a variable